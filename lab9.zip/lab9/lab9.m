clear all; close all
face=load('faces.mat').faces;
plot_face = reshape(face(:, 1:40),[56,46,1,40]);
montage(plot_face);
face=double(face);
test_face=[];
train_face=[];
k=1;
for i=1:400
    if mod(i,10)==0
        test_face = [test_face, face(:,i)];
    else
        train_face = [train_face,face(:,i)];
    end
end
plot_face = reshape (uint8(train_face),[56,46,1,360]);
montage(plot_face);

%compute the mean face
mean_face = [];
mean = zeros(2576,1);

for i=1:360
    for j=1:2576
        mean(j,1) = mean(j,1) + train_face(j,i);
    end
end
mean_face = mean/360;
A = zeros(2576,2576);
S2 = train_face - mean_face; 
A = S2*S2';

%computing eigenvectors and eigenvalues
[V,D] = eigs(A,400);

%plot eigenvalues
plot(diag(D),'LineWidth', 1.5);

%plot faces
figure 
for i=1:12
    subplot(2,6,i);
        imshow(reshape(V(:,i),56,46),[]);
        colormap("gray");
end



% Face detection
T = 1000; %you choose this
test1 = test_face(:,5) %pick any number until 40
a_weights = (test1 - mean_face)'*V;
test1_recovered = mean_face + V*a_weights'; 
%abs(test1 - test1_recovered) < T;
err = immse(test1_recovered, test1);
if err < T
    disp('It is a face');
end

%Face Recognition
test2 = test_face(:,15);
test2_w = (test2 - mean_face)'*V;
test2_recovered = (mean_face + V*test2_w');
test_face_a_weights = (test2 - mean_face)'*V;
a_weights_train = (train_face - mean_face)'*V;

err = [];
for i = 1:360
    err(i) = norm(test_face_a_weights - a_weights_train(i,:));
end
err_min = min(err);
ind = find(err_min==err);



%plot test image and train_face(Ind)
figure
subplot(1,2,1)
imshow(uint8(reshape(train_face(:,ind), 56,46)));
subplot(1,2,2)
imshow(uint8(reshape(test2, 56,46)));