clear all; close all; clc;

Left = imread('S00L.tif');
Right = imread('S00R.tif');
%Left = imread('left.png');
%Right = imread('right.png');

[row,col,ch] = size(Left);
if (ch == 3)
    ImLeft = rgb2gray(Left);
end

[row,col,ch] = size(Right);
if (ch == 3)
    ImRight = rgb2gray(Right);
end

k = 2;
omega = 30;
offset = omega + k;

img_left = double(ImLeft);
img_right = double(ImRight);

img_L = padarray(img_left,[offset offset],'both');
img_R = padarray(img_right,[offset offset],'both');

[ydim,xdim] = size(img_L);

disparity = zeros(ydim, xdim);

for xL = offset+1:1:xdim-offset-1
    for yL = offset+1:1:ydim-offset-1

        dist = []; %it keeps the displacement and the similarity values
        subL = img_L(yL-k : yL+k, xL-k : xL+k);
        
        for xR = xL:-1:xL-omega
            subR = img_R(yL-k : yL+k, xR-k : xR+k);

    
            C = sum(sum(-1*(subL - subR).^2));
            dist = [dist; xL - xR C];

        end

        ind = find(dist(:,2) == max(dist(:,2)));
        d = dist(ind(1),1);
        disparity(yL, xL) = d;

    end
end


disparity = uint8(disparity);

% Show stereo pair in a red-cyan anaglyph
imshow(stereoAnaglyph(ImLeft,ImRight));
% Show disparity map with colorbar
figure; imagesc(disparity); colormap jet; colorbar

%% Disparity built-in function part:

clear all; close all; clc;

Left = imread('S00L.tif');
Right = imread('S00R.tif');

[row,col,ch] = size(Left);
if (ch == 3)
    ImLeft = rgb2gray(Left);
end

[row,col,ch] = size(Right);
if (ch == 3)
    ImRight = rgb2gray(Right);
end

% Define maximum disparity
max_disp = 64;

% Compute disparity map
disparity_map = disparity(ImLeft, ImRight, 'Method', 'BlockMatching', 'BlockSize', 15, 'DisparityRange', [0 max_disp]);

% Show disparity map
imshow(disparity_map, [0 max_disp]);
colormap jet
colorbar