clear all; close all; clc;

img1 = 'floor.jpg';
img2 = 'library.jpg';

img3 = 'circlesBrightDark.png';
img4 = 'candies.png';

%tic
%img = imread(img2); 
%[H, theta, rho] = lab4houghlines(img);
%toc

tic
img = imread(img3); 
imshow(img);
[centerBright, radliBright, centerDark, radliDark] = lab4houghcircles(img);
toc