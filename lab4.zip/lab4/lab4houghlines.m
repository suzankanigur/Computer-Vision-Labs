function [H, theta, rho] = lab4houghlines(img)  %k is the window size, T is the treshold

[~,~,ch] = size(img);
if (ch == 3)
    img = rgb2gray(img);
end

%the selection of the edge detector is very significant
edge_detector = 'LoG';
img_edges = edge(img, edge_detector);
[H, theta, rho] = hough(img_edges);

%drawing Hough transformed version
imshow(H,[],'XData',theta,'YData',rho,...
            'InitialMagnification','fit');
xlabel('\theta'), ylabel('\rho');
axis on, axis normal, hold on;

%find peaks in hough transform image

%15 is the number of peaks it will show on the image
P  = houghpeaks(H,15,'Threshold',ceil(0.9*max(H(:))));
x = theta(P(:,2)); y = rho(P(:,1));
plot(x,y,'s','color','white');


%Finding the lines in the image by using these peak points and plotting them 

%Plot all the lines with green color and highlight the longest and shortest detected lines with cyan and red colors,
%respectively. What are the maximum and minimum lengths of the detected lines?

%10 and 40 are given in the pdf document

lines = houghlines(img_edges,theta,rho,P,'FillGap',10,'MinLength',40);
figure, imshow(img), hold on;
max_len = 0;
for k = 1:length(lines)
   xy = [lines(k).point1; lines(k).point2];
   
   plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','green');
   hold on;
   % Plot beginnings and ends of lines
   plot(xy(1,1),xy(1,2),'x','LineWidth',2,'Color','yellow');
   hold on;
   plot(xy(2,1),xy(2,2),'x','LineWidth',2,'Color','red');
   hold on;

   % Determine the endpoints of the longest line segment
   len = norm(lines(k).point1 - lines(k).point2);
   if ( len > max_len)
      max_len = len;
      xy_long = xy;
   end
end

%note: add hold on; after every plot
plot(xy_long(:,1),xy_long(:,2),'LineWidth',2,'Color','cyan'); %highlight the longest line

end
