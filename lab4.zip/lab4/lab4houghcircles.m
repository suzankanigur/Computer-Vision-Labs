function [centersBright, radiiBright, centersDark, radiiDark] = lab4houghcircles(img)  %k is the window size, T is the treshold

[~,~,ch] = size(img);
if (ch == 3)
    img = rgb2gray(img);
end

%Detect all the circles with 20 ≤ r ≤ 60, using Hough transform; and built-in 'imfindcircles' func.
%Change ‘Sensitivity’ factor and test the performance of circle detection.
%Change %ObjectPolarity’ parameter to detect ‘bright’ and ‘dark’ circles separately.

Rmin = 20;
Rmax = 60;


%Find all the bright circles in the image within the radius range:

[centersBright, radiiBright] = imfindcircles(img,[Rmin, Rmax],'ObjectPolarity','bright');

figure
subplot(1,3,1);
imshow(img); hold on;
title('Detected bright circles with 20<=r<=60');

viscircles(centersBright, radiiBright,'Color','b');
[centersBright, radiiBright] = imfindcircles(img,[Rmin, Rmax],'ObjectPolarity','bright','Sensitivity',0.9);

subplot(1,3,2);
imshow(img); hold on;
title('Detected bright and sensitive circles with 20<=r<=60');
viscircles(centersBright, radiiBright,'Color','r');

[centersBright, radiiBright] = imfindcircles(img,[Rmin, Rmax],'ObjectPolarity','bright','Sensitivity',0.9);
[centersDark, radiiDark] = imfindcircles(img,[Rmin, Rmax],'ObjectPolarity','dark','Sensitivity',0.9);


subplot(1,3,3);
imshow(img); hold on;
title('Detected bright and dark and sensitive circles with 20<=r<=60');
viscircles(centersDark, radiiDark,'LineStyle','--');
hold on;
viscircles(centersBright, radiiBright,'Color','b');

%imfindcircles(img,[Rmin, Rmax],'Sensitivity',0.9);
%Draw red dashed lines around the edges of the dark circles:

end
