function Result=Color_Matcher(im1,im2,coor1,coor2)
    S=size(coor1);
    coor_necessary1=[];
    for i=1:S(1) %eliminating the unnecessary edge points
        if((coor1(i,1)>554))
            coor_necessary1=[coor_necessary1;coor1(i,:)];
        end
    end
    coor_necessary1=coor_necessary1(5:331,:);
    S=size(coor2);
    coor_necessary2=[];
    for i=1:S(1) %eliminating the unnecessary edge points
        if(coor2(i,1)<227 && coor2(i,1)>145 )
            coor_necessary2=[coor_necessary2;coor2(i,:)];
        end
    end
    counter=0;
    for i=1:285
        if(im1(coor_necessary1(i,1),coor_necessary1(i,2),1)>=im2(coor_necessary2(i,1),coor_necessary2(i,2),1)-10 && im1(coor_necessary1(i,1),coor_necessary1(i,2),1)<=im2(coor_necessary2(i,1),coor_necessary2(i,2),1)+10)
            if (im1(coor_necessary1(i,1),coor_necessary1(i,2),2)>=im2(coor_necessary2(i,1),coor_necessary2(i,2),2)-10 && im1(coor_necessary1(i,1),coor_necessary1(i,2),2)<=im2(coor_necessary2(i,1),coor_necessary2(i,2),2)+10)
                if (im1(coor_necessary1(i,1),coor_necessary1(i,2),3)>=im2(coor_necessary2(i,1),coor_necessary2(i,2),3)-10 && im1(coor_necessary1(i,1),coor_necessary1(i,2),3)<=im2(coor_necessary2(i,1),coor_necessary2(i,2),3)+10)
                    counter=counter+1;
                end
            end
        end
    end
    
    if(counter>=(289*0.95))
        Result=1;
    else
        Result=0;
    end           
end
        