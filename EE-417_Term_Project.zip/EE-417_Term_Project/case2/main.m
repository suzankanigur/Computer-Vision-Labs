clear all, close all 
P1=imread("1.jpeg");
P2=imread("2.jpeg");
P3=imread("bw1.jpg");
P4=imread("bw2.jpg");



P3x=imresize(P3,[768 NaN]);
P4x=imresize(P4,[768 NaN]);

%imshowpair(P1x,P2x,"montage");

%%%% assumption: We know the concave-convex information about the edges,
%%%% thus we know which edges should be tested for the compatibility.

gray3=rgb2gray(P3x);
gray4=rgb2gray(P4x);

H3=Histogram(gray3);
H4=Histogram(gray4);
npix=1024*768;

cdf3=cdf_calculator(H3,npix);
cdf4=cdf_calculator(H4,npix);

BW3=otsubinary(cdf3,gray3);
BW4=otsubinary(cdf4,gray4);
SE=strel('square',3);

BW3=imerode(BW3,SE);
BW4=imerode(BW4,SE);

BW3x=imdilate(BW3,SE);
BW4x=imdilate(BW4,SE);
corners1=[];
corners1=Corner_Detector(BW3x);
%corners1(:,2)=corners1(:,2)-15;
figure
imshowpair(P1,BW3x,"montage");
hold on
plot(corners1(:,2),corners1(:,1),"r*");
hold off
corners2=[];
corners2=Corner_Detector(BW4x);
%corners2(:,1)=corners2(:,1)+5;
%corners2(:,2)=corners2(:,2)+15;
figure
imshowpair(P2,BW4x,"montage");
hold on
plot(corners2(:,2),corners2(:,1),"r*");
hold off
flag=Color_Matcher(P1,P2,corners1,corners2);
    

%% Otsu's Method 
function BW= otsubinary(cdf,image)

    S=size(image);
    i=S(1) 
    j=S(2);
    t=0;
    image=double(image);
    b_class_var=0;
    for c=1: +1: 256
        N1=0;
        N2=0;
        sum1=0;sum2=0;
        for a=1: +1 : i
            for b=1 : +1 :j
                if image(a,b)<c
                    sum1=sum1+image(a,b);
                    N1=N1+1;
                end
            end
        end
        if (N1==0)
            mu1=0;
        else
        mu1=sum1/N1;
        end
        for a=1: +1 : i
            for b=1 : +1 :j
                if image(a,b)>=c
                    sum2=sum2+image(a,b);
                    N2=N2+1;
                end
            end
        end
        
        if (N2==0)
            mu2=0;
        else
            mu2=sum2/N2;
        end
        w1=(cdf(c,1));
        w2=((1-cdf(c,1)));
        test_var=w1*w2*(mu1-mu2)*(mu1-mu2);
        if(test_var>b_class_var)
            b_class_var=test_var;
            t=c-1;
        end
    end
    for d=1: +1 : i
        for e=1 : +1 :j
            if(image(d,e)>=t)
                BW(d,e)=255;
            else
                BW(d,e)=0;
            end
        end
    end
    BW=uint8(BW);
end
%% cdf
function cdf=cdf_calculator(x,N)
    S=size(x);
    i=S(1);
    cdf=zeros(256,1);
     for a=1 : +1 : i
        for b=1 : +1 : a
            cdf(a)=(cdf(a)+x(b)/N);
        end
     end
end
%% Hist
function H=Histogram(x)
    S=size(x);
    i=S(1);
    j=S(2);
    H=zeros(256,1);

    for a=1 : +1 : i
        for b=1 : +1 : j
            H(x(a,b)+1,1)=H(x(a,b)+1,1)+1;
        end
    end
end
%% Morphologic Erosion 
function ME=Morp_Erosion(x)
  S=size(x);
    i=S(1);
    j=S(2);

    x=double(x);
    for a=1: +1 : i
        for b=1 : +1 :j
            if(a==1) 
                if(b==1)  %top left corner
                    d1=0;
                    d2=0;
                    d3=0;
                    d4=0;
                    d5=x(a,b);
                    d6=x(a,b+1);
                    d7=0;
                    d8=x(a+1,b);
                    d9=x(a+1,b+1);
                    
                
                elseif (b==j)  %top right corner 
                    d1=0;
                    d2=0;
                    d3=0;
                    d4=x(a,b-1);
                    d5=x(a,b);
                    d6=0;
                    d7=x(a+1,b-1);
                    d8=x(a+1,b);
                    d9=0;
                    
            
                else  %first row except corners
                    d1=0;
                    d2=0;
                    d3=0;
                    d4=x(a,b-1);
                    d5=x(a,b);
                    d6=x(a,b+1);
                    d7=x(a+1,b-1);
                    d8=x(a+1,b);
                    d9=x(a+1,b+1);
                    
                end 
            elseif (b==1) 
                if (a==i)  %bottom left corner
                    d1=0;
                    d2=x(144-1,b);
                    d3=x(a-1,b+1);
                    d4=0;
                    d5=x(a,b);
                    d6=x(a,b+1);
                    d7=0;
                    d8=0;
                    d9=0;
                    
    
                else  %first column except corners
                    d1=0;
                    d2=x(a-1,b);
                    d3=x(a-1,b+1);
                    d4=0;
                    d5=x(a,b);
                    d6=x(a,b+1);
                    d7=0;
                    d8=x(a+1,b);
                    d9=x(a+1,b+1); 
                    
            
                end
            elseif (a==i) 
                if (b==j)  %bottom right corner
                    d1=x(a-1,b-1);
                    d2=x(a-1,b);
                    d3=0;
                    d4=x(a,b-1);
                    d5=x(a,b);
                    d6=0;
                    d7=0;
                    d8=0;
                    d9=0;
                %operation-completed

                else  %last row except corners
                    d1=x(a-1,b-1);
                    d2=x(a-1,b);
                    d3=x(a-1,b+1);
                    d4=x(a,b-1);
                    d5=x(a,b);
                    d6=x(a,b+1);
                    d7=0;
                    d8=0;
                    d9=0;
                    
            
                end
            elseif (b==j)  %last column except corners 
                d1=x(a-1,b-1);
                d2=x(a-1,b);
                d3=0;
                d4=x(a,b-1);
                d5=x(a,b);
                d6=0;
                d7=x(a+1,b-1);
                d8=x(a+1,b);
                d9=0; 
                
                                     
            else  % other pixels 
                d1=x(a-1,b-1);
                d2=x(a-1,b);
                d3=x(a-1,b+1);
                d4=x(a,b-1);
                d5=x(a,b);
                d6=x(a,b+1);
                d7=x(a+1,b-1);
                d8=x(a+1,b);
                d9=x(a+1,b+1); 
            end
            if(d1~=0 && d2~=0 && d3~=0 && d4~=0 && d5~=0 && d6~=0 && d7~=0 && d8~=0 && d9~=0)
                ME(a,b)=x(a,b);
            else
                ME(a,b)=0;
            end
        end
    end
    
end