function corners= Corner_Detector(im) %since the built-in corner detectors are not helping with the current situation, a user-developed corner detection function became necessity 
    S=size(im);
    corners=[];
    % Top Right and Top Left Corner
    flag=0;
    im=uint8(im);
    counter=0;

    for c=1: S(2) % Top Left
        flag=0;
        for r=1: S(1)
            if(flag==0)
                if (im(r,c)==0)
                    corners=[corners;r c];
                    flag=1;
                end
            end
       end
    end

    for c=1: S(2) % Top Left
        flag=0;
        for r=S(1):-1:1
            if(flag==0)
                if (im(r,c)==0)
                    corners=[corners;r c];
                    flag=1;
                end
            end
       end
    end
    flag=0;
    for i=1:S(2) % Bottom Left
        for j=S(1):-1:1
            if(flag==0)
                if(im(j,i)==0)
                    corners=[corners;j i];
                    flag=1;
                end
            end
        end
    end
    flag=0;
     for i=S(2):-1:1 % Bottom Left
        for j=S(1):-1:1
            if(flag==0)
                if(im(j,i)==0)
                    corners=[corners;j i];
                    flag=1;
                end
            end
        end
    end
end