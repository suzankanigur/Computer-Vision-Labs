classdef Piece
    properties
        Image
        North {mustBeNumeric}
        South {mustBeNumeric}
        East  {mustBeNumeric}
        West  {mustBeNumeric}
        ID {mustBeNumeric}
    end
    methods
        function obj=problem(obj,n,s,e,w)
            obj.North=n;
            obj.South=s;
            obj.East=e;
            obj.West=w;
        end
        function obj=Piece(Im,id) %Constructor default assignment for edges is 0
            obj.Image=Im;
            obj.North=0;
            obj.South=0;
            obj.East=0;
            obj.West=0;
            obj.ID=id;
        end
        function object=concave_Convex(obj) %Concave&Convex detector, coordinates must be rearrenged
            I=obj.Image;
            ctr_black=0;
            % NORTH EDGE %
            for i=159:170 % 
                for j=501:524
                    if(I(i,j)~=0)
                        ctr_black=ctr_black+1;
                    end
                end
            end
            ctr_white=0;
            if(ctr_black>=8) % if convex 
                for i=228:239
                    for j=502:525
                        if(I(i,j)==0)
                            ctr_white=ctr_white+1;
                        end
                    end
                end
                if(ctr_white>=8) % if concave
                    obj.North=0;
                else
                    obj.North=-1;
                end
            else
                obj.North=1;
            end
            ctr_white=0;
            ctr_black=0;
            % SOUTH EDGE %
            for i=630:641 
                for j=503:526
                    if(I(i,j)~=0)
                        ctr_black=ctr_black+1;
                    end
                end
            end
            if(ctr_black>=8) %if convex
                for i=562:573
                    for j=504:527
                        if(I(i,j)==0)
                            ctr_white=ctr_white+1;
                        end
                    end
                end
                if(ctr_white>=8) % not convex
                    obj.South=0;
                else
                    obj.South=-1;
                end
            else
                obj.South=1;
            end
            ctr_white=0;
            ctr_black=0;
            % EAST EDGE %
            for i=391:402 
                for j=731:754
                    if(I(i,j)~=0)
                        ctr_black=ctr_black+1;
                    end
                end
            end
            if(ctr_black>=8) %if convex
                for i=396:407
                    for j=670:693
                        if(I(i,j)==0)
                            ctr_white=ctr_white+1;
                        end
                    end
                end
                if(ctr_white>=8) % not convex
                    obj.East=0;
                else
                    obj.East=-1;
                end
            else
                obj.East=1;
            end
            ctr_white=0;
            ctr_black=0;
            % WEST EDGE %
            for i=390:401 
                for j=284:307
                    if(I(i,j)~=0)
                        ctr_black=ctr_black+1;
                    end
                end
            end
            if(ctr_black>=8) % if convex 
                for i=393:404
                    for j=322:345
                        if(I(i,j)==0)
                            ctr_white=ctr_white+1;
                        end
                    end
                end
                if(ctr_white>=8) % not convex
                    obj.West=0;
                else
                    obj.West=-1;
                end
            else
                obj.West=1;
            end
            object=obj;
        end

    end
end