function possibles=Piece_Finder(piece_array)
    map_array=zeros(4,6,8);
    map_array(1,1,1)=1; % initializing the top left corner as reference 
    for x=1:4
        for y=1:6
            if (x==1 && y==1)
            else
                if(x==1) % first row 
                    if(y==1) % top left corner
                        %do nothing since top left corner is manually placed
                    elseif(y==6) % top right corner
                        for i=1:24
                            if(piece_array(i).North==0 && piece_array(i).East==0) % if top right corner
                                for a=1:8
                                    if(map_array(x,y,a)==0)
                                        map_array(x,y,a)=i;
                                        break
                                    end
                                end
                            end
                        end
                    else % other elements of first row 
                        for member= map_array(x,y-1)
                            if(member~=0)
                                for i=1:24
                                    if(member~=i)
                                    if(piece_array(member).East+ piece_array(i).West==0 && piece_array(i).North==0 && piece_array(i).South~=0 && piece_array(i).East~=0)
                                        for a=1:8
                                            if(map_array(x,y,a)==0)
                                                map_array(x,y,a)=i;
                                                break
                                            end
                                        end
                                    end
                                    end
                                end
                            end
                        end
                    end
                elseif (x==4) % last row
                    if(y==1) % bottom left corner
                        for i=1:24
                            if(piece_array(i).South==0 && piece_array(i).West==0) % if bottom left corner
                                for a=1:8
                                    if(map_array(x,y,a)==0)
                                        map_array(x,y,a)=i;
                                        break
                                    end
                                end
                            end
                        end
                    elseif(y==6) % bottom right corner
                        for i=1:24
                            if(piece_array(i).South==0 && piece_array(i).East==0) % if bottom right corner
                                for a=1:8
                                    if(map_array(x,y,a)==0)
                                        map_array(x,y,a)=i;
                                        break
                                    end
                                end
                            end
                        end
                    else % other elements of last row 
                        for member= map_array(x,y-1)
                            if(member~=0)
                                for i=1:24
                                    if (member~=i)
                                    if(piece_array(member).East+ piece_array(i).West==0 && piece_array(i).South==0 && piece_array(i).North~=0 && piece_array(i).East~=0)
                                        for a=1:4
                                            if(map_array(x,y,a)==0)
                                                map_array(x,y,a)=i;
                                                break
                                            end
                                        end
                                    end
                                    end
                                end
                            end
                        end
                    end
                elseif (y==1) % first col except corners 
                        for member=map_array(x-1,y)
                            if(member~=0)
                                for i=1:24
                                    if (member~=i)
                                    if(piece_array(member).South+piece_array(i).North==0 && piece_array(i).West==0 && piece_array(i).East~=0 && piece_array(i).South~=0)
                                        for a=1:8
                                            if(map_array(x,y,a)==0)
                                                map_array(x,y,a)=i;
                                                break
                                            end
                                        end
                                    end
                                    end
                                end
                            end
                        end
                elseif(y==6) % last col except corners
                        for member=map_array(x-1,y)
                            if(member~=0)
                                for i=1:24
                                    if (member~=i)
                                    if(piece_array(member).South+piece_array(i).North==0 && piece_array(i).East==0 && piece_array(i).West~=0 && piece_array(i).South~=0)
                                        for a=1:8
                                            if(map_array(x,y,a)==0)
                                                map_array(x,y,a)=i;
                                                break
                                            end
                                        end
                                    end
                                    end
                                end
                            end
                        end
                    else % inner pieces 
                        for member=map_array(x-1,y)
                            if(member~=0)
                                for memberx=map_array(x,y-1)
                                    if(memberx~=0)
                                        for i=1:24
                                            if (member~=i && memberx~=i)
                                            if(piece_array(member).South + piece_array(i).North==0 && piece_array(memberx).East + piece_array(i).West==0 &&piece_array(i).South~=0 && piece_array(i).East~=0)
                                                for a=1:8
                                                    if(map_array(x,y,a)==0)
                                                        map_array(x,y,a)=i;
                                                        break
                                                    end
                                                end
                                            end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                 end
            end
        end
    end
    possibles=map_array;
   end
                                                      
                        
