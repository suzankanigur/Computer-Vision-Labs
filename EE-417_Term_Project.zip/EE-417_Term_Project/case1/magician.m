function magician(p_array,map)
    figure
    ctr=1;
    for a=1:4
        for b=1:6
            Im=p_array(map(a,b,1)).Image;
            Im=uint8(Im);
            subplot(4,6,ctr)
            imshow(Im);
            ctr=ctr+1;
        end
    end
end