function Map_eliminated=eliminator(Map,piece_array)
flag=0;
while(~flag) % unique placements have eliminated from other arrays 
    for a=1:4 % MAtrix Rearranger 
        for b=1:6
            for c=1:8
                if(Map(a,b,c)==0)
                    for d=c+1:8
                        if(Map(a,b,d)~=0)
                            Map(a,b,c)=Map(a,b,d);
                            Map(a,b,d)=0;
                        end
                    end
                end
                            
            end
        end
    end
    change_detector=0;
    for i=1:4
        for j=1:6
            ctr=0;
            for k=1:8
                if(Map(i,j,k)~=0)
                    ctr=ctr+1;
                    detected=Map(i,j,k);
                end
            end
            if (ctr==1)
                for a=1:4
                    for b=1:6
                        if(a==i && b==j)
                        else
                            for c=1:8
                                if(Map(a,b,c)==detected)
                                    Map(a,b,c)=0;
                                    change_detector=1;
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    if(change_detector~=1)
        flag=1;
    end
ctrz=0;
for x=1:4 %%use newly received corner information for further eliminations 
    for y=1:6
        if (x==3 && y==1)
            for i=1:8
                if (Map(x,y,i)~=0)
                    if(piece_array(Map(x,y,i)).South+piece_array(Map(x+1,y,1)).North~=0)
                        Map(x,y,i)=0;
                        ctrz=ctrz+1;
                    end
                end
            end
        elseif(x==4 && y==5)
            for i=1:8
                if (Map(x,y,i)~=0)
                    if(piece_array(Map(x,y,i)).East+piece_array(Map(x,y+1,1)).West~=0)
                        Map(x,y,i)=0;
                        ctrz=ctrz+1;
                    end
                end
            end
        elseif(x==3 && y==6)
             for i=1:8
                if (Map(x,y,i)~=0)
                    if(piece_array(Map(x,y,i)).South+piece_array(Map(x+1,y,1)).North~=0)
                        Map(x,y,i)=0;
                        ctrz=ctrz+1;
                    end
                end
            end
        end
    end
end

for x=1:4 %%use newly received corner-neighbour information for further eliminations 
    for y=1:6
        if (x==3 && y==2)
                for member = Map(x,y-1)
                    if(member~=0)
                        for memberx=Map(x+1,y)
                            if(memberx~=0)
                                for i=1:8
                                    if(Map(x,y,i)~=0)
                                        if(piece_array(Map(x,y,i)).South+piece_array(memberx).North~=0 || piece_array(Map(x,y,i)).West+ piece_array(member).East~=0)
                                            Map(x,y,i)=0;
                                            ctrz=ctrz+1;
                                        end
                                    end
                                end
                            end
                        end
                    end
                end    
        elseif(x==3 && y==5)
                for member = Map(x,y+1)
                    if(member~=0)
                        for memberx=Map(x+1,y)
                            if(memberx~=0)
                                for i=1:8
                                    if(Map(x,y,i)~=0)
                                        if(piece_array(Map(x,y,i)).South+piece_array(memberx).North~=0 || piece_array(Map(x,y,i)).East+ piece_array(member).West~=0)
                                            Map(x,y,i)=0;
                                            ctrz=ctrz+1;
                                        end
                                    end
                                end
                            end
                        end
                    end
                end        

        end
    end
end
for a=1:4 %son şarkıyı çal kemancı 
    for b=1:6
        if(a==3 && b==4)
            N=Map(a-1,b,1);
            S=Map(a+1,b,1);
            if(Map(a,b+1,1)==0)
            E=Map(a,b+1,3);
            else
            E=Map(a,b+1,1);
            end
            W=Map(a,b-1,1);
            for c=1:8
                if(Map(a,b,c)~=0)
                    if(piece_array(Map(a,b,c)).North+piece_array(N).South~=0 || piece_array(Map(a,b,c)).South+piece_array(S).North~=0 || piece_array(Map(a,b,c)).East+piece_array(E).West~=0 || piece_array(Map(a,b,c)).West+piece_array(W).East~=0)
                        Map(a,b,c)=0;
                        ctrz=ctrz+1;
                    end
                end
            end
        end
    end
end
if(ctrz<1)
    flag=1;
end
end
Map_eliminated=Map;
end