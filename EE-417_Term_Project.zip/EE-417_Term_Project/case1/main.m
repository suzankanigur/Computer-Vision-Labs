close all, clear all

pieces_array=Piece.empty;

%{
P1=Piece(1,0,-1,1,0);
P2=Piece(2,1,1,-1,0);
P3=Piece(3,-1,-1,-1,0);
P4=Piece(4,1,0,-1,0);
P5=Piece(5,0,1,1,-1);
P6=Piece(6,-1,-1,-1,1);
P7=Piece(7,1,1,-1,1);
P8=Piece(8,-1,0,1,1);
P9=Piece(9,0,1,-1,-1);
P10=Piece(10,-1,-1,1,1);
P11=Piece(11,1,-1,-1,1);
P12=Piece(12,1,0,1,-1);

P13=Piece(13,0,-1,-1,1);
P14=Piece(14,1,1,1,-1);
P15=Piece(15,-1,1,-1,1);
P16=Piece(16,-1,0,-1,-1);
P17=Piece(17,0,1,-1,1);
P18=Piece(18,-1,-1,1,-1);
P19=Piece(19,1,1,1,1);
P20=Piece(20,-1,0,-1,1); 
P21=Piece(21,0,1,0,-1); **
P22=Piece(22,-1,-1,0,-1);
P23=Piece(23,1,-1,0,-1);
P24=Piece(24,1,0,0,1);

pieces_array=[pieces_array;P1];
pieces_array=[pieces_array;P2];
pieces_array=[pieces_array;P3];
pieces_array=[pieces_array;P4];
pieces_array=[pieces_array;P5];
pieces_array=[pieces_array;P6];

pieces_array=[pieces_array;P7];
pieces_array=[pieces_array;P8];
pieces_array=[pieces_array;P9];
pieces_array=[pieces_array;P10];
pieces_array=[pieces_array;P11];
pieces_array=[pieces_array;P12];

pieces_array=[pieces_array;P13];
pieces_array=[pieces_array;P14];
pieces_array=[pieces_array;P15];
pieces_array=[pieces_array;P16];
pieces_array=[pieces_array;P17];
pieces_array=[pieces_array;P18];

pieces_array=[pieces_array;P19];
pieces_array=[pieces_array;P20];
pieces_array=[pieces_array;P21];
pieces_array=[pieces_array;P22];
pieces_array=[pieces_array;P23];
pieces_array=[pieces_array;P24];
%}
str=".jpg";
pieces_array=Piece.empty;
npix=1024*768;
for i=1:24 % creating the object matrix 
    ch=int2str(i);
    name=strcat(ch,str);
    Ix=imread(name);
    Ix=rgb2gray(Ix);
    S=size(Ix);
    H=Histogram(Ix);
    cdff=cdf_calculator(H,npix);
    % Some Shifting Operations due to the picturing imperfections 
    if(i==7)
        Ix=imtranslate(Ix,[-70 0]);
    end
    if(i==9)
        Ix=imtranslate(Ix,[0,10]);
    end
    if(i==15)
        Ix=imtranslate(Ix,[0,15]);
    end
    if(i==17)
        Ix=imtranslate(Ix,[-25 10]);
    end
    if(i==20)
        Ix=imtranslate(Ix,[0 30]);
    end
    BW=otsubinary(cdff,Ix);
    SE = strel('square',3);
    BW2 = imdilate(BW,SE); %Morphologic Dilation --> built-in
    Morp=Morp_Erosion(BW2); %Morphologic Erosion --> self developed
    object=Piece(Morp,i);
    object=concave_Convex(object);
    if(i==21)
        object=problem(object,0,1,0,1);
    end
    pieces_array=[pieces_array;object];
    
end

flag=0;
s=size(pieces_array);
 

for i=1:s
    for j=i+1: s
        if(pieces_array(i).North==pieces_array(j).North &&pieces_array(i).South==pieces_array(j).South && pieces_array(i).West==pieces_array(j).West && pieces_array(i).East==pieces_array(j).East)
            flag=1;
        end
    end
end


Map= Piece_Finder(pieces_array);
Mapx= eliminator(Map,pieces_array);

magician(pieces_array,Mapx); % Sevgiler 

%% Otsu's Method 
function BW= otsubinary(cdf,image)
    S=size(image);
    i=S(1) 
    j=S(2);
    t=0;
    image=double(image);
    b_class_var=0;
    for c=1: +1: 256
        N1=0;
        N2=0;
        sum1=0;sum2=0;
        for a=1: +1 : i
            for b=1 : +1 :j
                if image(a,b)<c
                    sum1=sum1+image(a,b);
                    N1=N1+1;
                end
            end
        end
        if (N1==0)
            mu1=0;
        else
        mu1=sum1/N1;
        end
        for a=1: +1 : i
            for b=1 : +1 :j
                if image(a,b)>=c
                    sum2=sum2+image(a,b);
                    N2=N2+1;
                end
            end
        end
        
        if (N2==0)
            mu2=0;
        else
            mu2=sum2/N2;
        end
        w1=(cdf(c,1));
        w2=((1-cdf(c,1)));
        test_var=w1*w2*(mu1-mu2)*(mu1-mu2);
        if(test_var>b_class_var)
            b_class_var=test_var;
            t=c-1;
        end
    end
    for d=1: +1 : i
        for e=1 : +1 :j
            if(image(d,e)>=t)
                BW(d,e)=255;
            else
                BW(d,e)=0;
            end
        end
    end
    BW=uint8(BW);
end
%% Morphologic Erosion 
function ME=Morp_Erosion(x)
  S=size(x);
    i=S(1);
    j=S(2);

    x=double(x);
    for a=1: +1 : i
        for b=1 : +1 :j
            if(a==1) 
                if(b==1)  %top left corner
                    d1=0;
                    d2=0;
                    d3=0;
                    d4=0;
                    d5=x(a,b);
                    d6=x(a,b+1);
                    d7=0;
                    d8=x(a+1,b);
                    d9=x(a+1,b+1);
                    
                
                elseif (b==j)  %top right corner 
                    d1=0;
                    d2=0;
                    d3=0;
                    d4=x(a,b-1);
                    d5=x(a,b);
                    d6=0;
                    d7=x(a+1,b-1);
                    d8=x(a+1,b);
                    d9=0;
                    
            
                else  %first row except corners
                    d1=0;
                    d2=0;
                    d3=0;
                    d4=x(a,b-1);
                    d5=x(a,b);
                    d6=x(a,b+1);
                    d7=x(a+1,b-1);
                    d8=x(a+1,b);
                    d9=x(a+1,b+1);
                    
                end 
            elseif (b==1) 
                if (a==i)  %bottom left corner
                    d1=0;
                    d2=x(144-1,b);
                    d3=x(a-1,b+1);
                    d4=0;
                    d5=x(a,b);
                    d6=x(a,b+1);
                    d7=0;
                    d8=0;
                    d9=0;
                    
    
                else  %first column except corners
                    d1=0;
                    d2=x(a-1,b);
                    d3=x(a-1,b+1);
                    d4=0;
                    d5=x(a,b);
                    d6=x(a,b+1);
                    d7=0;
                    d8=x(a+1,b);
                    d9=x(a+1,b+1); 
                    
            
                end
            elseif (a==i) 
                if (b==j)  %bottom right corner
                    d1=x(a-1,b-1);
                    d2=x(a-1,b);
                    d3=0;
                    d4=x(a,b-1);
                    d5=x(a,b);
                    d6=0;
                    d7=0;
                    d8=0;
                    d9=0;
                %operation-completed

                else  %last row except corners
                    d1=x(a-1,b-1);
                    d2=x(a-1,b);
                    d3=x(a-1,b+1);
                    d4=x(a,b-1);
                    d5=x(a,b);
                    d6=x(a,b+1);
                    d7=0;
                    d8=0;
                    d9=0;
                    
            
                end
            elseif (b==j)  %last column except corners 
                d1=x(a-1,b-1);
                d2=x(a-1,b);
                d3=0;
                d4=x(a,b-1);
                d5=x(a,b);
                d6=0;
                d7=x(a+1,b-1);
                d8=x(a+1,b);
                d9=0; 
                
                                     
            else  % other pixels 
                d1=x(a-1,b-1);
                d2=x(a-1,b);
                d3=x(a-1,b+1);
                d4=x(a,b-1);
                d5=x(a,b);
                d6=x(a,b+1);
                d7=x(a+1,b-1);
                d8=x(a+1,b);
                d9=x(a+1,b+1); 
            end
            if(d1~=0 && d2~=0 && d3~=0 && d4~=0 && d5~=0 && d6~=0 && d7~=0 && d8~=0 && d9~=0)
                ME(a,b)=x(a,b);
            else
                ME(a,b)=0;
            end
        end
    end
    
end
%% cdf
function cdf=cdf_calculator(x,N)
    S=size(x);
    i=S(1);
    cdf=zeros(256,1);
     for a=1 : +1 : i
        for b=1 : +1 : a
            cdf(a)=(cdf(a)+x(b)/N);
        end
     end
end
%% Hist
function H=Histogram(x)
    S=size(x);
    i=S(1);
    j=S(2);
    H=zeros(256,1);

    for a=1 : +1 : i
        for b=1 : +1 : j
            H(x(a,b)+1,1)=H(x(a,b)+1,1)+1;
        end
    end
end
