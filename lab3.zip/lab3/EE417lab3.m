clear all; close all; clc;

img1 = imread('blocks.png'); 
img2 = imread('lab.png'); 
img3 = imread('notredame.jpg'); 
img4 = imread('house.jpg');


%%lab3ktcorners(img4,3,100000);
lab3Harriscorners(img3,3,9000);
%%lab3Harriscorners2(img3,3,2000000000);