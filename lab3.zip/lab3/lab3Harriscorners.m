function [C] = lab3Harriscorners(img,K,T)  %k is the window size, T is the treshold

[row,col,ch] = size(img);
if (ch == 3)
    img = rgb2gray(img);
end

img = double(img); 
img = imgaussfilt(img);
[Ix, Iy] = imgradientxy(img); 

k = (K-1)/2;
C=[];
for i =(k+1):(row-k-1)
    for j = (k+1): (col -k -1)
        sub_Ix = Ix(i-k : i+k , j-k : j+k);
        sub_Iy = Iy(i-k : i+k , j-k : j+k);

        x1 = sum(sum(sub_Ix .* sub_Ix));
        x2 = sum(sum(sub_Ix .* sub_Iy));
        y1 = sum(sum(sub_Ix .* sub_Iy));
        y2 = sum(sum(sub_Iy .* sub_Iy));
        
        H = [x1 x2; y1 y2];
        f = det(H)/trace(H); 
        if f > T
            C = [C; i j];
        end
    end
end
new_img = uint8(img);
imshow(new_img);
%axis on;
hold on;
plot(C(:,2),C(:,1),'r*');

end
