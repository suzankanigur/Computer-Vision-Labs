function I_new = lab2log(img,W)

[row,col,ch] = size(img);
if (ch == 3)
    img = rgb2gray(img);
end

laplace_matrix = [0 1 0; 1 -4 1; 0 1 0];
             
img_double = double(img); % image doubling
k = (W-1)/2;
for i =(k+1):(row -k -1)
    for j = (k+1): (col -k -1)
        subimg = img_double(i-k : i+k , j-k : j+k);
        laplace_subimg = subimg.*laplace_matrix;
        newImg(i,j) = sum(sum(laplace_subimg));
    end
end
I_new_img = uint8(newImg);

figure
subplot(2,2,1)
imshow(img);
title('Original image');

subplot(2,2,2)
imshow(I_new_img);
title('Laplacian of Gaussian Smoothed Image');

end
