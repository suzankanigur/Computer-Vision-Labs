clear all; close all; clc;

img1 = imread('baboon.png'); 
img2 = imread('house.png'); 
img3 = imread('Object_contours.jpg'); 

%%lab2gaussfilt(img1,5);
lab2prewitt(img2,3);
lab2sobel(img2,3);
lab2log(img3,3);