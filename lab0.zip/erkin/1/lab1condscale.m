function I_new = lab1condscale(img, img_ref)

[row,col,ch] = size(img);

if (ch == 3)
    img = rgb2gray(img);
end
[row,col,ch] = size(img_ref);

if (ch == 3)
    img_ref = rgb2gray(img_ref);
end

%Data = reshape(img, [1,Card]);

img_double = double(img);
img_ref_double = double(img_ref);
a = mean2(img_ref_double)*std2(img_double)/std2(img_ref_double)- mean2(img_double);
b = std2(img_ref_double)/std2(img_double);

I_new = b*(img_double + a);
I_new_img = uint8(I_new);

figure
subplot(2,2,1)
imshow(img);
title('original image');

subplot(2,2,2)
imshow(I_new_img);
title('linearly scaled image');

subplot(2,2,3)
img_histeq = histeq(img);
imhist(img_histeq);
title('histogram of original image');

subplot(2,2,4)
img_ref_histeq = histeq(I_new_img);
imhist(img_ref_histeq);
title('histogram of scaled image');


end
