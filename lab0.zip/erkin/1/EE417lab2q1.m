clear all; close all; clc;

img1 = imread('girl.jpg'); 
imgref = imread('pbear.jpg'); 

lab1linscale(img1);
lab1condscale(img1,imgref);

