%% webcam

clear all; close all;clc
camlist = webcamlist; %show all the webcams available
cam = webcam(1)
preview(cam);

%pausing the cam shot
%pause(5);

img = snapshot(cam);

imshow(img);
imwrite(img, 'snap.jpg');




%% RGB channels
clear all; close all;clc

img = imread('board.jpg');

%channel = img(rows, cols, channels);

rch = img(:, :, 1);
gch = img(:, :, 2);
bch = img(:, :, 3);

%visualize
fig = figure

subplot(2,2,1);

imshow(img);

subplot(2,2,1);
imshow(img);
title('original')

subplot(2,2,2);
imshow(rch);
title('red')

subplot(2,2,3);
imshow(gch);
title('green')

subplot(2,2,4);
imshow(bch);
title('blue')


%%RGB channels

clear all; close all;clc
img = imread('board.jpg')
im_gray = rgb2gray(img);

figure

subplot(1,2,1);
imshow(img)
subplot(1,2,2);
imshow(im_gray)


%%indexing in image

clear all; close all;clc

Im = imread('blocks.png');
Im2 = rgb2gray(Im);
figure, imshow(Im2)
D1 = double(Im2);
D2 = im2double(Im2);
disp('Image in uint8')
disp(Im2(190:200,320:330))
disp('Image in double with double() ')
disp(D1(190:200,320:330)) %cropping the image
disp('Image in double with im2double() ')
disp(D2(190:200,320:330))

%use double, not im2double
%placement of x and y in matrix is reversed in matlab


%% Image cropping
clear all; close all;clc

Im = imread('blocks.png')

%method1
cropped = Im(70:220,140:240);
figure
imshow(cropped)


%cropped2 = imcrop(Im, [140 70 100 150]);




%% finding interested pixels
clear all; close all;clc

Im = imread('blocks.png');
Im = rgb2gray(Im);
Im2 = zeros(size(Im));
k = find((Im>170)&(Im<200));
Im2(k)=255; %painting white
imshow(Im2)


%% func of mean and variance


