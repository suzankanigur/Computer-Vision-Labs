function I_new = lab1linscale(img)

[row,col,ch] = size(img);
Card = row*col;

if (ch == 3)
    img = rgb2gray(img);
end

img_double = double(img);
a = -min(img_double(:));
b = 255/(max(img_double(:)) - min(img_double(:)));
I_new = b*(img_double + a);
I_new_img = uint8(I_new);

figure
subplot(2,2,1)
imshow(img);
title('original image');

subplot(2,2,2)
imshow(I_new_img);
title('linearly scaled image');

subplot(2,2,3)
imhist(img);
subplot(2,2,4)
imhist(I_new_img);

end