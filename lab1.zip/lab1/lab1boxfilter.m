function I_new = lab1boxfilter(img, img_ref)
[row,col,ch] = size(img);

if (ch == 3)
    img = rgb2gray(img);
end

W=5 W=2k+1
K = (W-1)/2


for i=(k+1): (row-k-1)
    for j=(k+1):(col-k-1)
        subImg=img_double(i-k:I+k, J-k:j+k) %1:3
        newImg(i,j) = sum(sum(subimg*W/(2*k+1))) / ((2*k+1))^2);

end

