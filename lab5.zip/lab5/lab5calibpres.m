clear all; close all; clc;

img = imread('calibrationObject.png');
%img = imread('board2.jpg');

[~,~,ch] = size(img);
if (ch == 3)
    img = rgb2gray(img);
end

img_edge = edge(img, 'LoG');

[H, theta, rho] = hough(img_edge);
P  = houghpeaks(H,25,'Threshold',ceil(0.45*max(H(:))));
hough_lines = houghlines(img_edge,theta,rho,P,'FillGap',10,'MinLength',20);

%drawing all the lines 
figure, imshow(img), hold on;
max_len = 0;
for k = 1:length(hough_lines)
 xy = [hough_lines(k).point1; hough_lines(k).point2];
 plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','green');
 % plot beginnings and ends of hough_lines
 plot(xy(1,1),xy(1,2),'x','LineWidth',2,'Color','yellow');
 plot(xy(2,1),xy(2,2),'x','LineWidth',2,'Color','red');

end

%% 35 13


%these are the theta and rho points, coming from the Hough function. Find
%them in
theta35 = hough_lines(35).theta;
rho35 = hough_lines(35).rho;

theta13 = hough_lines(13).theta;
rho13 = hough_lines(13).rho;

%we chose a point and checked the points by hand
%140,130 - 167,317  -8, 120
%36,129 - 187, 187  -69 -107


A = [cosd(theta35), sind(theta35); cosd(theta13), sind(theta13)];
b = [rho35;rho13];

res = inv(A)*b;


%%
x = 0:0.1:350;
y13=(rho13 - x*cosd(theta13)) / sind(theta13);
y35 = (rho35 - x*cosd(theta35)) / sind(theta35);


figure
imshow(img)
hold on;
plot(x,y13,'Linewidth',2,'Color','magenta'); hold on
plot(x,y35,'Linewidth',2,'Color','magenta'); hold on

plot(res(1), res(2), 'O', 'Markersize', 4, 'MarkerEdgeColor','yellow', 'LineWidth',2);

%%
img_corn = corner(img, 'harris');

plot(img_corn(:,1),img_corn(:,2),'r*');

%145.1158 and 170.3173 are the double values we got from  Harris
%99 216
%102 220
distance1 = sqrt((99-99.3387)^2 + (216-217.5662)^2)
distance2 = sqrt((102-99.3387)^2 + (220-217.5662)^2)


%% POSTLAB

clear all; close all; clc;

img = imread('board2.jpg');

[~,~,ch] = size(img);
if (ch == 3)
    img = rgb2gray(img);
end

img_edge = edge(img, 'LoG');

[H, theta, rho] = hough(img_edge);
P  = houghpeaks(H,65,'Threshold',ceil(0.5*max(H(:))));
hough_lines = houghlines(img_edge,theta,rho,P,'FillGap',20,'MinLength',30);

%drawing all the lines 
figure, imshow(img), hold on;
max_len = 0;
for k = 1:length(hough_lines)
 xy = [hough_lines(k).point1; hough_lines(k).point2];
 plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','green');
 % plot beginnings and ends of hough_lines
 plot(xy(1,1),xy(1,2),'x','LineWidth',2,'Color','yellow');
 plot(xy(2,1),xy(2,2),'x','LineWidth',2,'Color','red');

end

%% 

%it contains all the values of the lines we chose.
linePairs = [
    hough_lines(112) hough_lines(59);
    hough_lines(89) hough_lines(109);
    hough_lines(89) hough_lines(139);
    hough_lines(101) hough_lines(44);
    hough_lines(77) hough_lines(7);
    hough_lines(116) hough_lines(37);
    hough_lines(54) hough_lines(76);
    hough_lines(18) hough_lines(102);
];

houghCorners = [];

for i=1:8
    A = [cosd(linePairs(i,1).theta), sind(linePairs(i,1).theta); cosd(linePairs(i,2).theta), sind(linePairs(i,2).theta)];
    b = [linePairs(i,1).rho;linePairs(i,2).rho];
    res = inv(A)*b;
    houghCorners = [houghCorners; res]; %the results are kept in houghCorners vector
end


%%
size(img)

%%
x = 0:0.1:4032;

%4032 is our range for this pic.

figure
imshow(img)
hold on;

for i = 1:8 
    y1 = (linePairs(i,1).rho - x*cosd(linePairs(i,1).theta)) / sind(linePairs(i,1).theta);
    y2 = (linePairs(i,2).rho - x*cosd(linePairs(i,2).theta)) / sind(linePairs(i,2).theta);
    plot(x,y1,'Linewidth',2,'Color','magenta'); hold on
    plot(x,y2,'Linewidth',2,'Color','magenta'); hold on
end


for i = 1:2:16
    plot(houghCorners(i), houghCorners(i+1), 'O', 'Markersize', 4, 'MarkerEdgeColor','yellow', 'LineWidth',2);
end

%%
size(img)
%%
img_corn = corner(img, 'harris','QualityLevel', 0.02, 'SensitivityFactor', 0.2, N=3000);

plot(img_corn(:,1),img_corn(:,2),'r*');
