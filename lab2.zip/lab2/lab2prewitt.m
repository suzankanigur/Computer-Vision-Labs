function I_new = lab2prewitt(img,W)

[row,col,ch] = size(img);
if (ch == 3)
    img = rgb2gray(img);
end

filter_X = [-1 0 1; -1 0 1; -1 0 1];
filter_Y = [-1 -1 -1; 0 0 0; 1 1 1];              
img_double = double(img);
k = (W-1)/2;
for i =(k+1):(row -k -1)
    for j = (k+1): (col -k -1)
        sub_img = img_double(i-k : i+k , j-k : j+k);
        filtered_image_X = sub_img.*filter_X;
        filtered_image_Y = sub_img.*filter_Y;
        filtered_image = filtered_image_X + filtered_image_Y;
        newImg(i,j) = sum(sum(filtered_image));
        newImg_X(i,j) = sum(sum(filtered_image_X));
        newImg_Y(i,j) = sum(sum(filtered_image_Y));
    end
end
I_new_img = uint8(newImg);
I_new_img_X = uint8(newImg_X);
I_new_img_Y = uint8(newImg_Y);

figure
subplot(3,2,1)
imshow(img);
title('Original Image');

subplot(3,2,2)
imshow(I_new_img);
title('Image Prewitt');

subplot(3,2,3)
imhist(img);
title('Histogram of Original Image');

subplot(3,2,4)
imhist(I_new_img);
title('Histogram of Prewitt');

subplot(3,2,5)
imshow(I_new_img_X);
title('Vertical Prewitt');

subplot(3,2,6)
imshow(I_new_img_Y);
title('Horizontal Prewitt');

end