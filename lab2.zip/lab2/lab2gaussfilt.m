function I_new = lab2gaussfilt(img, W)

[row,col,ch] = size(img);

if (ch == 3)
    img = rgb2gray(img);
end

kernel = [1 4 7 4 1; 4 16 26 16 4; 7 26 41 26 7; 4 16 26 16 4; 1 4 7 4 1];
kernel = kernel/273;
img_double = double(img); 

k = (W-1)/2;
for i =(k+1):(row-k-1)
    for j = (k+1): (col-k-1)
        subimg = img_double(i-k : i+k , j-k : j+k);
        new_mat = kernel.*subimg % dot product
        newImg = sum(sum(new_mat));
    end
end
I_new_img = uint8(newImg);


figure
subplot(2,2,1)
imshow(img);
title('original image');

subplot(2,2,2)
imshow(I_new_img);

subplot(2,2,4)
img_ref_histeq = histeq(I_new_img);
imhist(img_ref_histeq);
title('Histogram');

end